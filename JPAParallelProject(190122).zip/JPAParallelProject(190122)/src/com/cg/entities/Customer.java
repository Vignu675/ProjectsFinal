package com.cg.entities;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@SuppressWarnings("serial")
@Entity
public class Customer implements Serializable {

	@Id
	private int customerId;
	private String name;
	private long phoneNo;
	private String custAddress;//extra
	private long custAadhaarNo;//extra
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "accountNo")
	private Account account;

	static int counter=1;
	
	public Customer() {
		this.customerId=counter++;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public String getCustAddress() {
		return custAddress;
	}

	public void setCustAddress(String custAddress) {
		this.custAddress = custAddress;
	}

	public long getCustAadhaarNo() {
		return custAadhaarNo;
	}

	public void setCustAadhaarNo(long custAadhaarNo) {
		this.custAadhaarNo = custAadhaarNo;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", name=" + name + ", phoneNo=" + phoneNo + ", custAddress="
				+ custAddress + ", custAadhaarNo=" + custAadhaarNo + ", account=" + account + "]";
	}
	
	
	
}
