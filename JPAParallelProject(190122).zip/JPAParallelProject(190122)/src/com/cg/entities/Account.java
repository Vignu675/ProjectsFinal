package com.cg.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@SuppressWarnings("serial")
@Entity
@Table(name = "Account1")
public class Account implements Serializable {
	
	@Id
	private int accountNo;
	private String accType;//extra
	private double balance;
	
	
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String getaccType() {
		return accType;
	}
	public void setaccType(String accType) {
		this.accType = accType;
	}
	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", accType=" + accType + ", balance=" + balance + "]";
	}
	
	
	
}
