package com.cg.exception;

public class AccountExistException extends Exception {
	public AccountExistException(String s) {
		System.out.println(s);
	}
}
