package com.cg.client;

import java.util.Scanner;

public class client {
	static int id=0;
	public static void main(String[] args) {
		
		while(true) {
			System.out.println("^^^WELCOME TO XYZ BANK^^^");
			System.out.println("'Enter Your Choice'");
			System.out.println("1.Create Account");
			System.out.println("2.Show Balance");
			System.out.println("3.Deposit");
			System.out.println("4.Withdraw");
			System.out.println("5.Fund Transfer");
			System.out.println("6.Print Transaction");
			System.out.println("7.Exit");
			System.out.println("******************");
			
			@SuppressWarnings("resource")
			Scanner sc=new Scanner(System.in);
			int choice=sc.nextInt();
			CustomerUi cuobj=new CustomerUi();
			switch(choice) {
				case 1:
					cuobj.createCustomer();
					break;
				case 2:
					cuobj.showBalance();
					break;
				case 3:
					cuobj.deposit();
					break;
				case 4:
					cuobj.withdraw();
					break;
				case 5:
					cuobj.fundTransfer();
					break;
				case 6:
					cuobj.printTransaction();
					break;
				case 7:
					System.exit(0);
			}	
		}
	}
}
