package ui;

import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

import bean.Account;
import bean.Customer;
import bean.TransactionDetails;
import dao.CustomerDao;
import exceptions.FundTransferException;
import exceptions.ShowBalanceException;
import exceptions.WithdrawException;
import service.CustomerService;

@SuppressWarnings("static-access")
public class AccountUI {
	long accNo = 123001;
	Scanner sc = new Scanner(System.in);
	// CustomerDao data = new CustomerDao();
	CustomerService csobj = new CustomerService();

	public void createAccount() {

		System.out.println("Enter Customer name: ");
		String name = sc.next();

		System.out.println("Enter Customer's MobileNo: ");
		long no = sc.nextLong();

		System.out.println("Enter Customer's Address: ");
		String add = sc.next();

		System.out.println("Enter Customer's Aadhaar No: ");
		long ano = sc.nextLong();

		System.out.println("Customer Account created successfully");
		System.out.println("Enter Account Type: ");
		String type = sc.next().toUpperCase();
		Customer cobj = new Customer(name, no, add, ano);
		Account aobj = new Account();
		aobj.setAccNo(accNo++);
		aobj.setAccType(type);
		aobj.setBalance(minBalance());
		aobj.setCobj(cobj);

		csobj.serviceStoreCustomer(aobj);
		System.out.println(aobj);
		System.out.println("*******");

		// Transaction

		TransactionDetails trans = new TransactionDetails();
		trans.setAccountNumber(aobj.getAccNo());
		trans.setCredit(aobj.getBalance());
		trans.setDebit(0);
		trans.setAmount(aobj.getBalance());
		csobj.setTransactionList(trans);

	}

	public double minBalance() {
		System.out.println("Enter Minimum Balance(>=1000): ");
		// double minbal1=0;
		double minbal = sc.nextDouble();
		if (minbal >= 1000) {
			return minbal;
		} else {
			System.out.println("Sorry. . . Please deposite minimum balance");
			return minBalance();
		}
		// return minbal;
	}

	public void showBalance() {
		HashMap<Long, Account> map = csobj.serviceRetrieveCollection();
		System.out.println("Enter the account number:\n");
		long input = sc.nextLong();

		try {
			if (map.containsKey(input)) {
				Account aobj1 = csobj.serviceRetrieveCustomer(input);

				System.out.println(aobj1.getBalance());
				System.out.println("*******");
			} else
				throw new ShowBalanceException("Account does not exist.");
		} catch (ShowBalanceException e) {
			System.out.println(e);
			System.out.println("Enter valid Account Number");
			System.out.println("*******");
			showBalance();
		}
	}

	public void depositAmount() {
		System.out.println("Enter Account Number: ");
		long input = sc.nextLong();
		System.out.println("Enter Deposite Amount: ");
		double deposite = sc.nextDouble();
		Account aobj = csobj.serviceRetrieveCustomer(input);
		double newbal = aobj.getBalance() + deposite;
		aobj.setBalance(newbal);
		System.out.println("Amount Deposited Successfully to" + input + ". Balance:" + newbal);
		System.out.println("*******");

		TransactionDetails trans = new TransactionDetails();
		trans.setAccountNumber(aobj.getAccNo());
		trans.setCredit(deposite);
		trans.setDebit(0);
		trans.setAmount(aobj.getBalance());
		csobj.setTransactionList(trans);

	}

	public void withdrawAmount() {
		System.out.println("Enter the account number:\n");
		long input = sc.nextLong();
		System.out.println("Enter the withdraw amount:\n");
		double withdrawAmount = sc.nextDouble();
		Account aobj = csobj.serviceRetrieveCustomer(input);

		try {
			if (aobj.getBalance() > withdrawAmount) {
				double newBalance = aobj.getBalance() - withdrawAmount;
				aobj.setBalance(newBalance);
				System.out.println("Withdraw Successfull from"+ input+  "of"  +newBalance+ "/-");
				System.out.println("*******");

			} else
				throw new WithdrawException("Exception: Withdraw amount is greater than balance.");
		} catch (WithdrawException e) {
			System.out.println(e);
			System.out.println("*******");
			withdrawAmount();
		}

		TransactionDetails trans = new TransactionDetails();
		trans.setAccountNumber(aobj.getAccNo());
		trans.setCredit(0);
		trans.setDebit(withdrawAmount);
		trans.setAmount(aobj.getBalance());
		csobj.setTransactionList(trans);

	}

	public void fundTransfer() {
		System.out.println("Enter the sender account number:\n");
		long senderAccNo = sc.nextLong();
		System.out.println("Enter the receiver account number:\n");
		long receiverAccNo = sc.nextLong();
		System.out.println("Enter the amount to transfer:\n");
		double transferAmount = sc.nextDouble();
		Account asobj = csobj.serviceRetrieveCustomer(senderAccNo);
		Account arobj = csobj.serviceRetrieveCustomer(receiverAccNo);

		try {
			if (asobj.getBalance() > transferAmount) {
				double senderNewBalance = asobj.getBalance() - transferAmount;
				asobj.setBalance(senderNewBalance);

				double receiverNewBalance = arobj.getBalance() + transferAmount;
				arobj.setBalance(receiverNewBalance);

				System.out.println("Fund transfer successful from " + senderAccNo + " to " + receiverAccNo);
				System.out.println("*******");
			} else
				throw new FundTransferException("Insufficient balance.");
		} catch (FundTransferException e) {
			System.out.println(e);
		}

		// Transactions
		TransactionDetails trans = new TransactionDetails();
		trans.setAccountNumber(asobj.getAccNo());
		trans.setCredit(0);
		trans.setDebit(transferAmount);
		trans.setAmount(asobj.getBalance());
		csobj.setTransactionList(trans);

		trans.setAccountNumber(arobj.getAccNo());
		trans.setCredit(transferAmount);
		trans.setDebit(0);
		trans.setAmount(arobj.getBalance());
		csobj.setTransactionList(trans);

	}

	public void getTransactionDetails() {
		System.out.println("Enter Account Number");
		long accountNo = sc.nextLong();
		List<TransactionDetails> resultList = csobj.getTransactionDetails(accountNo);
		System.out.println("Transaction List: ");
		for (TransactionDetails transactionDetails : resultList) {

			if (transactionDetails.getAccountNumber() == accountNo) {
				System.out.println(transactionDetails);
			}

		}

	}

}
