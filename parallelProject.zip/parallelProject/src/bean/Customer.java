package bean;

public class Customer {
	 String custName;
	 long mobileNo;
	 String custAddress;
	 long custAadhaarNo;
	public Customer(String custName, long mobileNo, String custAddress,
			long custAadhaarNo) {
		this.custName = custName;
		this.mobileNo = mobileNo;
		this.custAddress = custAddress;
		this.custAadhaarNo = custAadhaarNo;
		
	}
	
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getCustAddress() {
		return custAddress;
	}
	public void setCustAddress(String custAddress) {
		this.custAddress = custAddress;
	}
	public long getCustAadhaarNo() {
		return custAadhaarNo;
	}
	public void setCustAadhaarNo(long custAadhaarNo) {
		this.custAadhaarNo = custAadhaarNo;
	}

	@Override
	public String toString() {
		return "Customer Name=" + custName + ",\nMobileNo=" + mobileNo + ",\nCustomer Address=" + custAddress
				+ ",\nCustomer AadhaarNo=" + custAadhaarNo;
	}
}