package bean;

public enum AccType {
		SAVINGS,CURRENT;
}
