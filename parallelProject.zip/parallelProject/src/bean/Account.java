package bean;

public class Account {
	private long accNo = 123000;
	private String AccType;
	private double balance;
	Customer cobj;
	
	public Account() {
		
	}

	public long getAccNo() {
		return accNo;
	}

	public void setAccNo(long accNo) {
		this.accNo = accNo;
	}

	public String getAccType() {
		return AccType;
	}

	public void setAccType(String accType) {
		AccType = accType;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public Customer getCobj() {
		return cobj;
	}

	public void setCobj(Customer cobj) {
		this.cobj = cobj;
	}

	@Override
	public String toString() {
		return "Account Number=" + accNo + ",\nAccount Type=" + AccType + ",\nAvailable Balance=" + balance
				+ ",\nCustomer Details=" + cobj;
	}
}
