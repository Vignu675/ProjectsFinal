package service;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import bean.Account;
import bean.TransactionDetails;
import dao.CustomerDao;

public class CustomerService {
		
		CustomerDao cdobj=new CustomerDao();
		Account account = new Account();
		//CustomerDao data = new CustomerDao();
		
		public void serviceStoreCustomer(Account aobj )
		{
			cdobj.daoStoreCustomer(aobj);
		}
		
		public Account serviceRetrieveCustomer(long accNo){
			return cdobj.daoRetrieveCustomer(accNo);
		}

		public HashMap<Long, Account> serviceRetrieveCollection() {
		
			return cdobj.daoRetrieveCustomer();
		}

		public void setTransactionList(TransactionDetails trans) {

			cdobj.setTransactionDetails(trans);
			
		}

		public List<TransactionDetails> getTransactionDetails(long accNo) {

			return cdobj.getTransactionDetails(accNo);
			
		}

	
		

		

	
}
