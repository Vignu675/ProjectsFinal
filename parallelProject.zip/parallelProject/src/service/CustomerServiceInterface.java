package service;

public interface CustomerServiceInterface {

}
