package dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import bean.Account;
import bean.TransactionDetails;

import java.util.Map;



public class CustomerDao {
	
		Map<Long,Account> accountMap=new HashMap<Long,Account>();
		List<TransactionDetails> transactionList = new ArrayList<>();
		
		public void daoStoreCustomer(Account aobj){
			long key=aobj.getAccNo();
			accountMap.put(key,aobj);
		}
	
		public Account daoRetrieveCustomer(long accNo){
			return accountMap.get(accNo);
		}

		public HashMap<Long, Account> daoRetrieveCustomer() {
		
			return (HashMap<Long, Account>) accountMap;
		}

		public void setTransactionDetails(TransactionDetails trans) {
			
			transactionList.add(trans);
			
		}

		public List<TransactionDetails> getTransactionDetails(long accNo) {

			return transactionList;
			
		}
		

}
